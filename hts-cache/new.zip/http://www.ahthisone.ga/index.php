<!DOCTYPE html>
<html>
<head>
	<meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0 user-scalable=0' />
	<title>Homepage:Fellow Seekers on the path</title>
	<link href="css/style.css" type="text/css" rel="stylesheet" />
</head>
<body>

<div id="wrapper">
	<div id="banner">
		<h1 id="main_title">Fellow Seekers on the path</h1>
	</div>
	<div id="main">	<div id="left">
		<div id="feed_area">
				
				<div class="post"><img src="media/Osho_library.jpg" ><div class="status"><h2><b>INVITATION LETTER</b></h2><br /><br />This to inform all the visitors of this site is that this site is just an archive project which will be consist of screenshot from e-books or computer screen with some kind of application running on it.<br /><br /><br /><br />Most of the screenshot of e-book are taken from the Books of "OSHO" the bookman Hence you could call this archive project as a <i>Bookmarks from the Bookman</i><br /><br />THIS PROJECT IS INSPIRED BY smr.co.in & blog.smr.co.in<br /><br /><b>THE PATH WE WILL HAVE TO GO THROUGH</b><br /><i><br /> These are the three steps before you become enlightened:<br /><br />Buddha comes behind you like a shadow, the first step.<br /><br />Buddha comes before you and you become the shadow, the second step.<br /><br />Your shadow disappears in the buddha. You are no more, only buddha is... the third and the final step. </i><br /> <br />Thanks for reading</div>
					<div class="status_meta"><font class="tags">Default</font><font class="uploades_on">2019-08-09 15:47:02</font></div>
					</div><div class="post"><div class="status"><br /><br /><h2><b>INFORMATION REGARDING CATEGORIES</b></h2><br /><br /><i>Bookmarks from the Bookman</i> ~ This categorie will consist of osho Hindi Video clips which are mostly extracted from his talk "KOPLEN PHIR PHOOT AAYE" for full Video discourses you can have a look inside :github.com/abhi18022/the-bookman ~ there you could find that out. "Sorry unable to link the direct link due to SERVER policy.(Look for the mystery school link on that site you can find a collection of of Videos of Koplen Phir Phoot Aaye)<br /><br /><br /><br /><i>Archive</i> ~ This Categorie consist of many screenshot which are Roughly taken and miss arranged and messy.But as these pieces of TEXT belongs to "AH THIS ONE" movement of my life hence I will like it to share with you all visitor.<br /><br /><i>to know from which part of OSHO books these piece of text belongs to </i> you can use this TOOL: https://www.sannyas.wiki/index.php?title=Osho_Books_on_CD-ROM which you can download from https://www.oshorajneesh.com/osho-books-database-download.htm<br /><br />YOU JUST NEED TO LEARN TO USE THE ADVANCE SEARCH OPTION IN THIS TOOL and you will easy get from which ebook this piece of text belongs to. As if you wish to read the whole Book you can get it there.<br /><br />Few of the hindi text mostly belongs to : Koplen phir phoot aayen & Phir amrit ki boond padi.<br /><br /><br /><br /></i>thanks for reading</i><br /><br /></div>
					<div class="status_meta"><font class="tags">INFO</font><font class="uploades_on">2019-08-13 13:21:14</font></div>
					</div><div class="post"><div class="status"><h2><b>Online links Bookmarks related to osho and religion</b> </h2><br /><br /><br /><br />1) <b>OSHOWORLD</b> ~ http://www.oshoworld.com/discourses/audio.asp :Here you can find all the osho discourses in audio form free to download<br /><br /><br /><br />2) <b>Direct Download Links for ENGLISH DISCOURSES</b> ~ https://justpaste.it/75mro : Use a effective downloading manager to download them<br /><br /><br /><br />3) <b>Direct Download Links for HINDI DISCOURSES</b> ~ https://justpaste.it/2h1dw : Use a effective downloading manager to download them<br /><br /><br /><br />4) <b>LINKS LIST</b> ~ https://www.satrakshita.com/osho_links_eng.htm<br /><br /><br /><br />5) <b>Resource list</b> ~ https://researchweb.iiit.ac.in/~smr/bookmarks.html : Look for the osho+meditation section<br /><br /><br /><br />6) <b> ESSAY ON OSHO </b> ~ http://meditation-handbook.50webs.com/ : left site posts contain essay on OSHO (mostly negative)<br /><br /><br /><br />7) <b> OSHO FRIENDS </b> ~ http://www.sannyas.wiki/ :contains a hell lot of information about him<br /><br /><br /><br />8) <b> VIDEO DISCOURSES TELEGRAM CHANNEL and Many other resources </b> ~ https://github.com/Abhi18022/The-Bookman/blob/master/README.md<br /><br /><br /><br />9) <b> OSHO VIDEO ONLINE HOSTED</b> ~ https://bit.ly/308V3Jj :Site contain almost all the osho Videos English/hindi Both.<br /><br /><br /><br />10) <b> OSHO links list on Curlie </b> ~ https://curlie.org/Society/Religion_and_Spirituality/Mysticism/Mystics_and_Teachers/Osho/ :Contain a lot of osho sites Link<br /><br /><br /><br /><i> You could found a lot of osho website online there by Googling but few listed below here are the least known One MOSTLY THE 6,7 & 8 <br /><br />Thank you for reading</i></div>
					<div class="status_meta"><font class="tags">INFO</font><font class="uploades_on">2019-08-14 06:23:49</font></div>
					</div><div class="post"><div class="status"><h2><b> The Video wrongly explained</b></h2><br /><br /><iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/vRVVOViXGXw" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe><br /><br /><br /><br /><b> at 1:44 </b> : <i>Full enlightenment is produced by genetics of brain NOT by meditation</i> ~ ENLIGHTENMENT IT SELF IS A ABSURD CONCEPT So, yeah it is stupid to talk about it. And it could not be the brain genetics any how !!!!!  <br /><br /><br /><br />Other then that few of the Ideas on this Video and the essay on http://meditation-handbook.50webs.com/meditation2.html are brilliant.<br /><br /><br /><br /><b>few Points to addon it</b> : EVERY THING AROUND US IS A COMPLEX FORM OF PROCESS HENCE AT A POINT IT BECOMES DIFFICULT TO SAY WHICH IS ALIVE AND WHICH IS NOT.<br /><br />a rock is also a complex form of process with subtel ability to response and a human is also a complex form of process with far more ability to response !!!! as they are the most evolved and complex consciousness known till date.<br /><br /><b>http://meditation-handbook.50webs.com/</b> ~ Here is the Website link.<br /><br /><i>thanks for reading</i><br /><br /></div>
					<div class="status_meta"><font class="tags">INFO</font><font class="uploades_on">2019-08-14 06:37:27</font></div>
					</div><div class="post"><div class="status"><b><h2>THE LAST ARUGUMENT</h2></b><br /><a href="https://ibb.co/qrCPXGH"><img src="https://i.ibb.co/crw7M5W/THE-LAST-AURGUMENT.png" alt="THE-LAST-AURGUMENT" border="0" /></a></div>
					<div class="status_meta"><font class="tags">Archive</font><font class="uploades_on">2019-08-18 17:12:38</font></div>
					</div><div class="post"><div class="status"><b><h2>Edgar Cayce</h2></b> <br /><br /><iframe width="560" height="315" src="https://www.youtube.com/embed/HDOIr_kZMO4" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe><br /><br /><i>Perhaps this Video contain a hell lot of things but from part 34:20 where it talks about edger cacey seems true to me.</i><br /><br />THE 5TH ROOTED MAN <br />which can help the whole humanity <br />OSHO also in his last talk "ZEN communisum wild fire" have been talking about that only a man rooted into earth<br />or something like that <br /><br />thanks a lot for reading guys<br /><a href=https://www.edgarcayce.org/>www.edgarcayce.org</a><br /></div>
					<div class="status_meta"><font class="tags">JUST FEW LAST HITS ON HEAD</font><font class="uploades_on">2019-08-18 17:43:45</font></div>
					</div><div class="post"><div class="status"><h2><b>THE FINAL DISPLAY</b></h2><br /><br /><iframe src='https://my.mail.ru/video/embed/9181434795060625412' width='626' height='367' frameborder='0' scrolling='no' webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe><br /><br />This make me feels like i am the one of the hope perhaps i have to do it first to help rest of the peoples to make it happen too.<br /><br />This is how peoples most of the peoples are.<br /><br /><br /><a href="https://ibb.co/wwwRD15"><img src="https://i.ibb.co/611m65j/This-this-makes-me-feel-like-sometime-that-may-be-i-am-the-one-of-the-HOPE-OF-THE-WHOLE-HUMANITY.png" alt="This-this-makes-me-feel-like-sometime-that-may-be-i-am-the-one-of-the-HOPE-OF-THE-WHOLE-HUMANITY" border="0"></a><br /><br />~FREEDOM FROM INDIVIUALITY the Ulimate one <br /></div>
					<div class="status_meta"><font class="tags">JUST FEW LAST HITS ON HEAD</font><font class="uploades_on">2019-08-18 17:55:21</font></div>
					</div><div class="post"><div class="status"><iframe src='https://my.mail.ru/video/embed/9181434795060625426' width='626' height='367' frameborder='0' scrolling='no' webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe><br /><br /><b>Punishment crime and criminal mind</b><br />Well explained </div>
					<div class="status_meta"><font class="tags">Bookmarks from the Bookman</font><font class="uploades_on">2019-08-19 09:44:00</font></div>
					</div><div class="post"><div class="status"><iframe src='https://my.mail.ru/video/embed/9181434795060625417' width='626' height='367' frameborder='0' scrolling='no' webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe><br /><br /><b>THE MYSTERY SCHOOL of OSHO</b><br />He describes about what is lacking in the schools</div>
					<div class="status_meta"><font class="tags">Bookmarks from the Bookman</font><font class="uploades_on">2019-08-19 09:54:30</font></div>
					</div><div class="post"><div class="status"><b>Communisum As a Possibility</b><br /><iframe src='https://my.mail.ru/video/embed/9181434795060625410' width='626' height='367' frameborder='0' scrolling='no' webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe><br /></div>
					<div class="status_meta"><font class="tags">Bookmarks from the Bookman</font><font class="uploades_on">2019-08-19 10:03:56</font></div>
					</div><a href="index.php?page=2">Next Page</a>				
			</div>
		</div>
		
		<div id="right">
                        <div class="right_head"><a href="index.php">Home</a></div>
			<div class="right_head">Categories</div>
			<ul class="categories">
			
			<li><a href="read.php?category=0">Default</a></li><li><a href="read.php?category=5">Bookmarks from the Bookman</a></li><li><a href="read.php?category=8">The Nerd Section</a></li><ul class="subcategories"><li><a href="read.php?category=8&subcategory=6">Computers</a></li><li><a href="read.php?category=8&subcategory=7">Others</a></li></ul><li><a href="read.php?category=7">INFO</a></li><li><a href="read.php?category=6">Archive</a></li><ul class="subcategories"><li><a href="read.php?category=6&subcategory=1">ZEN the Ultimate</a></li><li><a href="read.php?category=6&subcategory=2">Koplen Phir phoot aayen (Hindi)</a></li><li><a href="read.php?category=6&subcategory=3">Rough Collection</a></li><li><a href="read.php?category=6&subcategory=4">Devotee of OSHO</a></li><li><a href="read.php?category=6&subcategory=5">New Humanity</a></li></ul><li><a href="read.php?category=9">JUST FEW LAST HITS ON HEAD</a></li><li><a href="read.php?category=10">Stories I do like</a></li>			
			</ul>		</div>
	
	
	
	
	</div>
	
	<div id="banner">
		<div id="footer">
		 Confession: author himself have been longing for more awareness and more understanding, hence there is probability of over-speaking in the posts hence you could skip reading the parts you won't find of much interest or which make you feel like it doesn't belongs to you also authors suffers from dyslexia So, please avoid spelling or punctuation mistakes or let him know
				</div>
	</div>
</div>

</body>
</html>